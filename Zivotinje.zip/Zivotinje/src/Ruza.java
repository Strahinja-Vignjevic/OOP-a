public class Ruza implements ZivoBice, Biljka{
    @Override
    public void vrsiFotosintezu() {
        System.out.print("Vrsim fotosintezu ");
    }

    @Override
    public void zivi() {
        System.out.print("Zivim u zemlji!");
    }

    public String toString(){
        return "Ja sam ruza!";
    }

    public void predstaviSe(){
        System.out.print("Oces da te bocnem?");
        zivi();
        vrsiFotosintezu();
        System.out.println();
    }
}
