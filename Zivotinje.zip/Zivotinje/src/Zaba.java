public class Zaba implements ZivoBice, Vodozemac, Cujni{
    @Override
    public void oglasiSe() {
        System.out.print("Kre kre!");
    }

    @Override
    public void zivi() {
        System.out.print("Zivim mirno!");
    }

    @Override
    public void plivaj() {
        System.out.print("Plivam u reci!");
    }

    public String toString(){
        return "Ja sam ruza!";
    }

    public void predstaviSe(){
        System.out.print("Moje ime je Kermit!");
        oglasiSe();
        zivi();
        plivaj();
        System.out.println();
    }
}
