import java.util.ArrayList;
import java.util.Scanner;

public class ZoloskiVrt {
    public static void main(String[] args){
        ArrayList<Cujni> cujnaBica = new ArrayList<>();
        ArrayList<ZivoBice> zivaBica = new ArrayList<>();
        Zaba zaba = new Zaba();
        zaba.predstaviSe();
        Bakterija bakterija = new Bakterija();
        bakterija.predstaviSe();
        Jabuka jabuka = new Jabuka();
        jabuka.predstaviSe();
        Ruza ruza = new Ruza();
        ruza.predstaviSe();
        Koza koza = new Koza();
        koza.predstaviSe();
        Macka macka = new Macka();
        macka.predstaviSe();

        cujnaBica.add(zaba);
        cujnaBica.add(koza);
        cujnaBica.add(macka);
        zivaBica.add(macka);
        zivaBica.add(zaba);
        zivaBica.add(bakterija);
        zivaBica.add(jabuka);
        zivaBica.add(ruza);

        Scanner scanner = new Scanner(System.in);
        int days = scanner.nextInt();

        for(int i = 0; i < days; i++) {
            System.out.println("Dan " + (i + 1));
            for (ZivoBice zivoBice : zivaBica) System.out.println(zivoBice.toString());
        }

        for(int i = 0; i < days; i++) {
            System.out.println("Dan " + (i + 1));
            for (Cujni cujni : cujnaBica) System.out.println(cujni.toString());
        }
    }
}
