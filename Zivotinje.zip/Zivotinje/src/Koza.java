public class Koza implements Zivotinja, ZivoBice, Cujni{
    @Override
    public void oglasiSe() {
        System.out.print("Meee, meee!");
    }

    @Override
    public void kreciSe() {
        System.out.print("Krecem se zustro!");
    }

    @Override
    public void zivi() {
        System.out.print("Zivim zdravo!");
    }

    public String toString(){
        return "Ja sam koza!";
    }

    public void predstaviSe(){
        System.out.print("Dacu ti mleko!");
        oglasiSe();
        kreciSe();
        zivi();
        System.out.println();
    }
}
