public class Jabuka implements Biljka, ZivoBice{
    @Override
    public void zivi() {
        System.out.print("Zivim na grani!");
    }

    @Override
    public void vrsiFotosintezu() {
        System.out.print("Vrsim fotosintezu sa efikasnoscu 5%!");
    }

    public String toString(){
        return "Ja sam jabuka!";
    }

    public void predstaviSe(){
        System.out.print("Av av!");
        zivi();
        vrsiFotosintezu();
        System.out.println();
    }
}
