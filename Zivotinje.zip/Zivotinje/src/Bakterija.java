public class Bakterija implements ZivoBice{
    @Override
    public void zivi() {
        System.out.print("Zivim brzo!");
    }

    public String toString(){
        return "Ja sam bakterija!";
    }

    public void predstaviSe(){
        System.out.print("Buci buci, problem je u kuci! Ja sam bakterija!");
        zivi();
        System.out.println();
    }
}
