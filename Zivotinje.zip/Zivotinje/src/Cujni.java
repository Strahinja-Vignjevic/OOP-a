public interface Cujni {
    void oglasiSe();
}
