public interface Zivotinja {
    void kreciSe();
}
