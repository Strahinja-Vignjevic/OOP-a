public interface Vodozemac {
    void plivaj();
}
