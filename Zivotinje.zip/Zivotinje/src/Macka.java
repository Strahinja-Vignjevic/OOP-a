public class Macka implements ZivoBice, Zivotinja, Cujni{
    @Override
    public void oglasiSe() {
        System.out.print("Mjau!");
    }

    @Override
    public void zivi() {
        System.out.print("Zivim lenjo!");
    }

    @Override
    public void kreciSe() {
        System.out.print("Krecem se zajebano!");
    }

    public String toString(){
        return "Ja sam macka!";
    }

    public void predstaviSe(){
        System.out.print("Daj mi mleko!");
        oglasiSe();
        kreciSe();
        zivi();
        System.out.println();
    }
}
