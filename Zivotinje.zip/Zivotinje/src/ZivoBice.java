public interface ZivoBice {
    void zivi();
}
