public interface Biljka {
    void vrsiFotosintezu();
}
